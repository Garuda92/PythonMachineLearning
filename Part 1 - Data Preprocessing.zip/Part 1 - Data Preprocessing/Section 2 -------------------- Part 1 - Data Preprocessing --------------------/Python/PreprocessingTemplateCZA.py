# -*- coding: utf-8 -*-
"""
Created on Tue May 26 07:08:51 2020

@author: CzeitnerAZ
"""
"""
Szükséges Libraryk importálásas
"""
import numpy  as np
import matplotlib.pyplot
import pandas as pd
from sklearn.impute import SimpleImputer

dataset = pd.read_csv('Data.csv')
"""
InDependent/független változók
"""
X = dataset.iloc[:, :-1].values

"""
Dependent/függő változó
"""
y = dataset.iloc[:,-1].values

"""
A numerikus hiányzó adatok esetén at átlagot vesszük

"""

imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
imputer.fit(X[:, 1:3])
X[:, 1:3] = imputer.transform(X[:, 1:3])


"""
Onehot encode
Kategórikus adatokat konvertál be numerikussá
"""
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
ct = ColumnTransformer(transformers=[('encoder',OneHotEncoder(),[0])], remainder='passthrough')
X = np.array(ct.fit_transform(X))


"""
Label Encoder
Bináris értékkészletű jellemzőket konvertál 0 és 1 -é
"""
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
y = le.fit_transform(y)

"""
Train/Test split
"""

"""
Random_state 1 azért kell, hogy a vélszám nekem is és az oktatónak is ugyan azt adja vissza
"""
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size = 0.2, random_state = 1)



"""
Feature scaling
Standardisation vs Normalisation

Sztenderdizáció mindig jó Normalizáció inkább akkor, ha az adatok eloszlása normál
"""

from sklearn.preprocessing import StandardScaler
sc = StandardScaler()

X_train[:,3:] = sc.fit_transform(X_train[:,3:] )
X_test[:,3:]  =  sc.fit_transform(X_test[:,3:] )
print(X_train)
print('--------------------------------------')
print(X_test)