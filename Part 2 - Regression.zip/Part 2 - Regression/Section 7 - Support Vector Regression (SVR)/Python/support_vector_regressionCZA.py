# -*- coding: utf-8 -*-
"""
Created on Tue May 26 07:08:51 2020

@author: CzeitnerAZ
"""
"""
Szükséges Libraryk importálásas
"""
import numpy  as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.impute import SimpleImputer

dataset = pd.read_csv('Position_Salaries.csv')
"""
InDependent/független változók
"""
X = dataset.iloc[:, 1:-1].values

"""
Dependent/függő változó
"""
# az y változóval az a gond, hogy az alakja horizontális ezt a lenti függvénnyel átkonvertáljuk vertikálisra
y = dataset.iloc[:,-1].values
#print(y)
y = y.reshape(len(y),1)
#print(y)

# külön SC objektumot kellett készíteni a Dependent és az independent változókra, mivel más síkon van a kettő értéke
#Azt látni kell, hogy ennek így az eredménye is Standard Scaled lesz így majd vissza kell konvertálni
from sklearn.preprocessing import StandardScaler
scX = StandardScaler()
X = scX.fit_transform(X)
scy = StandardScaler()
y = scy.fit_transform(y)

from sklearn.svm import SVR
regressor = SVR(kernel = 'rbf')

regressor.fit(X, y)

#ahhoz, hogy a 6.5 höz tartozó értéket megkapjuk magát a 6.5-t és transzformálni kell SC-vel hiszen maga a model is már transzformálva van.
#regressor.predict(scX.transform([[6.5]]))
#ennek megvalósítására használjuk az scy.inverse_transform metódust
scy.inverse_transform(regressor.predict(scX.transform([[6.5]])))



plt.scatter(scX.inverse_transform(X),scy.inverse_transform(y), color= 'red')
plt.plot(scX.inverse_transform(X), scy.inverse_transform(regressor.predict(X)), color='blue')       
plt.title('Truth of bluff (Supper Vector Regression)')
plt.xlabel('Position level')
plt.ylabel('Salary')
plt.show()

