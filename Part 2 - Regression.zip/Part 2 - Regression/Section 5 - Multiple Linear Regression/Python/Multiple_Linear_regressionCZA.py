# -*- coding: utf-8 -*-
"""
Created on Thu May 28 07:30:07 2020

@author: CzeitnerAZ
"""

import numpy  as np
import matplotlib.pyplot
import pandas as pd
from sklearn.impute import SimpleImputer

dataset = pd.read_csv('50_Startups.csv')

"""
InDependent/független változók
"""
X = dataset.iloc[:, :-1].values

"""
Dependent/függő változó
"""
y = dataset.iloc[:,-1].values

from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
ct = ColumnTransformer(transformers=[('encoder',OneHotEncoder(),[3])], remainder='passthrough')
X = np.array(ct.fit_transform(X))

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size = 0.2, random_state = 0)



from sklearn.linear_model import LinearRegression
regressor = LinearRegression() 
regressor.fit(X_train, y_train)
y_pred = regressor.predict(X_test)

#2 tizedesjegyig levágja a printelni kívánt szöveget
np.set_printoptions(precision = 2)
#horizontális jelenleg a y_pred tömb és ebből csinálunk vertikálust
print(np.concatenate((y_pred.reshape(len(y_pred),1), y_test.reshape(len(y_test),1)),1))
