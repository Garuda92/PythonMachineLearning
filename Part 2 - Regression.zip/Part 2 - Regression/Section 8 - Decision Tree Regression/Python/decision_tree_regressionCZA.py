# -*- coding: utf-8 -*-
"""
Created on Tue May 26 07:08:51 2020

@author: CzeitnerAZ
"""
"""
Szükséges Libraryk importálásas
"""
import numpy  as np
import matplotlib.pyplot
import pandas as pd
from sklearn.impute import SimpleImputer

dataset = pd.read_csv('position_salaries.csv')
"""
InDependent/független változók
"""
X = dataset.iloc[:, 1:-1].values

"""
Dependent/függő változó
"""
y = dataset.iloc[:,-1].values


from sklearn.tree import DecisionTreeRegressor 
regressor = DecisionTreeRegressor(random_state = 0)
regressor.fit(X,y)

regressor.predict([[6.5]])
print(regressor.predict([[6.5]]))



