# -*- coding: utf-8 -*-
"""
Created on Tue May 26 07:08:51 2020

@author: CzeitnerAZ
"""
"""
Szükséges Libraryk importálásas
"""
import numpy  as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.impute import SimpleImputer

dataset = pd.read_csv('Position_Salaries.csv')
"""
InDependent/független változók
"""
X = dataset.iloc[:, 1:-1].values

"""
Dependent/függő változó
"""
y = dataset.iloc[:,-1].values


"""
Nagyon kicsi az adattömeg ezért nem osztjuk szét training és test settre
Elsőnek egy sima Lineáris regressziós modelt készítünk
"""
from sklearn.linear_model import LinearRegression
lin_reg =  LinearRegression()
lin_reg.fit(X,y)

#A polinomial  classal módosítjuk a Lineáris Regressziós modellünket Poly Lin-re (valójában építünk egy újat lin_reg_2 néven)
from sklearn.preprocessing import PolynomialFeatures
#eredetileg 2-vel néztük meg az már közelebb volt a jóhoz, de a 4-el most már nagyon király.
poly_reg = PolynomialFeatures(degree=4)
X_poly = poly_reg.fit_transform(X)

lin_reg_2 = LinearRegression()

lin_reg_2.fit(X_poly, y)


#Lineáris Regressziós model eredményének kirajzolása, hogy lásd mennyire gyenge az eredmény
plt.scatter(X,y, color= 'red')
plt.plot(X, lin_reg.predict(X), color= 'blue')
plt.title('Truth or Bluff (Linear Regression)')
plt.xlabel('Position Level')
plt.ylabel('Salary')
plt.show()


#Polinomial regression model
plt.scatter(X,y, color= 'red')
plt.plot(X, lin_reg_2.predict(X_poly), color= 'blue')
plt.title('Truth or Bluff (Linear Regression)')
plt.xlabel('Position Level')
plt.ylabel('Salary')
plt.show()




#mennyi lehet egy konkrét ember fizetése
lin = lin_reg.predict([[6.5]])
poly = lin_reg_2.predict(poly_reg.fit_transform([[6.5]]))


print([[6.5]])